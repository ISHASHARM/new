//double of a no
var double = function (n1) {
    return 2 * n1;
};
console.log(double(4));
//print hello name
var hello = function (name) {
    return "Hello " + name;
};
console.log(hello("Isha"));
