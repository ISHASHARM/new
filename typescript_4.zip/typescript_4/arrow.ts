//double of a no
var double=(n1:number):number=>{
    return 2*n1;
};
console.log(double(4));

//print hello name
var hello=(name:string):string=>{
    return "Hello "+name;
};
console.log(hello("Isha"));