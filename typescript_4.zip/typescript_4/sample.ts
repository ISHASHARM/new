for(let i=0;i<10;i++){
    console.log(i);
}
//console.log(i); // using let will not allow to usein entore code since let is block scoped

const pi=3.14;
console.log(pi);// const is same as final in java


var pro=function(x:number,y:number):number{
    return x*y;
}
console.log(pro(9,8));